g++ player1.cpp -Ofast -o CustomPlayer
